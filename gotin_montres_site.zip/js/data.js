let montres = [
    {
        "id": 0,
        "nom": "Montre Zenith Elite!",
        "prix": "8500",
        "description": "Titane, automatique, cuir italien",
        "images": [
            "images/montre1-1.avif",
            "images/montre1-2.avif",
            "images/montre1-3.avif",
            "images/montre1-4.avif"
        ]
    },
    {
        "id": 1,
        "nom": "Rolex Submariner",
        "prix": "12000",
        "description": "Acier, lunette c\u00e9ramique, \u00e9tanche 300 m",
        "images": [
            "images/montre2-1.avif",
            "images/montre2-2.avif",
            "images/montre2-3.avif",
            "images/montre2-4.avif"
        ]
    },
    {
        "id": 2,
        "nom": "Breitling Superocean!",
        "prix": "6000",
        "description": "Heritage B20 Automatic 42",
        "images": [
            "images/montre3-1.avif",
            "images/montre3-2.avif",
            "images/montre3-3.avif",
            "images/montre3-4.avif"
        ]
    },
    {
        "id": 3,
        "nom": "MONTRE",
        "prix": "120",
        "description": "cvbcv",
        "images": [
            "images/montre3-2.avif",
            "images/montre2-3.avif",
            "images/montre1-2.avif",
            "images/montre3-2.avif"
        ]
    }
];